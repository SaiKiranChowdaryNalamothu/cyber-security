Copy & Replace the fixed files to installation directory.

----------------------------


		PreActiveFile.Com